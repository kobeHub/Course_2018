# Welcome to Inno Markdown Editor

##What's Inno Markdown Editor? 

<br><br>
*Inno markdown editor is a simple, light-weight,* 
<br>*cross-platform, multilingual Markdown document processing tools*


<br><br>
## 特点：

+ 支持markdown基本的语法属性，サポート日本語（支持日语），Поддержка русского языка(支持俄语)......
<br>等各种全球通用语言的编辑
+ 提供实时的markdown 向html格式转换，以供用户进行实时的预览
+ 支持图片，超链接，不同字体格式以及自定义排版
+ 高效文档产出工具，提供便利的博客书写

##TODO:
+ 导出html到blog
+ 部分语法的未实现，如表情，多选框等等


<br><br>
![image](/home/kobe/图片/Wallpapers/opear.jpg)
<br><br>
**Just text and try yourself!**

**[Author:Inno Jia](http://www.innohub.top/)**















