/**
 * Classes used while running the program in command line.
 */
package com.nilhcem.md2html.console;
