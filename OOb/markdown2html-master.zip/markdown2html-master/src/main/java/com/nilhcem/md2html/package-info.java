/**
 * Entry point of the application.
 */
package com.nilhcem.md2html;
