/**
 * Classes used while running the program in a GUI.
 */
package com.nilhcem.md2html.gui;
