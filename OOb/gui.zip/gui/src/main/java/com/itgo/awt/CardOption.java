package com.itgo.awt;

public enum CardOption {
    FIRST, PREVIOUSE, NEXT, LAST;
}