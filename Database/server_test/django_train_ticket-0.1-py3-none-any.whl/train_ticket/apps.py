from django.apps import AppConfig


class TrainTicketConfig(AppConfig):
    name = 'train_ticket'
